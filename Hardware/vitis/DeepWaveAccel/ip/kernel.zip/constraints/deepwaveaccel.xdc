set_false_path -through [get_ports g_b_mem_M_real_193[*]]
set_false_path -through [get_ports g_b_mem_M_imag_192[*]]
set_false_path -through [get_ports g_tau_mem[*]]
set_false_path -through [get_ports g_lap_rest[*]]
