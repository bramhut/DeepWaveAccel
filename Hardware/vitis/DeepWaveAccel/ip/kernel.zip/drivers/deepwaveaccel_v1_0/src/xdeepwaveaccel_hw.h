// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// CTRL_BUS
// 0x000 : reserved
// 0x004 : reserved
// 0x008 : reserved
// 0x00c : reserved
// 0x010 : Data signal of b_ddr
//         bit 31~0 - b_ddr[31:0] (Read/Write)
// 0x014 : Data signal of b_ddr
//         bit 31~0 - b_ddr[63:32] (Read/Write)
// 0x018 : reserved
// 0x01c : Data signal of tau_ddr
//         bit 31~0 - tau_ddr[31:0] (Read/Write)
// 0x020 : Data signal of tau_ddr
//         bit 31~0 - tau_ddr[63:32] (Read/Write)
// 0x024 : reserved
// 0x028 : Data signal of lap_ddr
//         bit 31~0 - lap_ddr[31:0] (Read/Write)
// 0x02c : Data signal of lap_ddr
//         bit 31~0 - lap_ddr[63:32] (Read/Write)
// 0x030 : reserved
// 0x034 : Data signal of goer_cfg_COS_OMEGA_0
//         bit 17~0 - goer_cfg_COS_OMEGA_0[17:0] (Read/Write)
//         others   - reserved
// 0x038 : reserved
// 0x03c : Data signal of goer_cfg_COS_OMEGA_1
//         bit 17~0 - goer_cfg_COS_OMEGA_1[17:0] (Read/Write)
//         others   - reserved
// 0x040 : reserved
// 0x044 : Data signal of goer_cfg_COS_OMEGA2_0
//         bit 17~0 - goer_cfg_COS_OMEGA2_0[17:0] (Read/Write)
//         others   - reserved
// 0x048 : reserved
// 0x04c : Data signal of goer_cfg_COS_OMEGA2_1
//         bit 17~0 - goer_cfg_COS_OMEGA2_1[17:0] (Read/Write)
//         others   - reserved
// 0x050 : reserved
// 0x054 : Data signal of goer_cfg_SIN_OMEGA_0
//         bit 17~0 - goer_cfg_SIN_OMEGA_0[17:0] (Read/Write)
//         others   - reserved
// 0x058 : reserved
// 0x05c : Data signal of goer_cfg_SIN_OMEGA_1
//         bit 17~0 - goer_cfg_SIN_OMEGA_1[17:0] (Read/Write)
//         others   - reserved
// 0x060 : reserved
// 0x064 : Data signal of debl_cfg_n_layers
//         bit 7~0 - debl_cfg_n_layers[7:0] (Read/Write)
//         others  - reserved
// 0x068 : reserved
// 0x06c : Data signal of debl_cfg_K
//         bit 5~0 - debl_cfg_K[5:0] (Read/Write)
//         others  - reserved
// 0x070 : reserved
// 0x074 : Data signal of debl_cfg_lap_off_0
//         bit 11~0 - debl_cfg_lap_off_0[11:0] (Read/Write)
//         others   - reserved
// 0x078 : reserved
// 0x07c : Data signal of debl_cfg_lap_off_1
//         bit 11~0 - debl_cfg_lap_off_1[11:0] (Read/Write)
//         others   - reserved
// 0x080 : reserved
// 0x084 : Data signal of debl_cfg_lap_off_2
//         bit 11~0 - debl_cfg_lap_off_2[11:0] (Read/Write)
//         others   - reserved
// 0x088 : reserved
// 0x08c : Data signal of debl_cfg_lap_off_3
//         bit 11~0 - debl_cfg_lap_off_3[11:0] (Read/Write)
//         others   - reserved
// 0x090 : reserved
// 0x094 : Data signal of debl_cfg_lap_off_4
//         bit 11~0 - debl_cfg_lap_off_4[11:0] (Read/Write)
//         others   - reserved
// 0x098 : reserved
// 0x09c : Data signal of debl_cfg_lap_off_5
//         bit 11~0 - debl_cfg_lap_off_5[11:0] (Read/Write)
//         others   - reserved
// 0x0a0 : reserved
// 0x0a4 : Data signal of debl_cfg_theta_0
//         bit 17~0 - debl_cfg_theta_0[17:0] (Read/Write)
//         others   - reserved
// 0x0a8 : reserved
// 0x0ac : Data signal of debl_cfg_theta_1
//         bit 17~0 - debl_cfg_theta_1[17:0] (Read/Write)
//         others   - reserved
// 0x0b0 : reserved
// 0x0b4 : Data signal of debl_cfg_theta_2
//         bit 17~0 - debl_cfg_theta_2[17:0] (Read/Write)
//         others   - reserved
// 0x0b8 : reserved
// 0x0bc : Data signal of debl_cfg_theta_3
//         bit 17~0 - debl_cfg_theta_3[17:0] (Read/Write)
//         others   - reserved
// 0x0c0 : reserved
// 0x0c4 : Data signal of debl_cfg_theta_4
//         bit 17~0 - debl_cfg_theta_4[17:0] (Read/Write)
//         others   - reserved
// 0x0c8 : reserved
// 0x0cc : Data signal of debl_cfg_theta_5
//         bit 17~0 - debl_cfg_theta_5[17:0] (Read/Write)
//         others   - reserved
// 0x0d0 : reserved
// 0x0d4 : Data signal of debl_cfg_theta_6
//         bit 17~0 - debl_cfg_theta_6[17:0] (Read/Write)
//         others   - reserved
// 0x0d8 : reserved
// 0x0dc : Data signal of debl_cfg_theta_7
//         bit 17~0 - debl_cfg_theta_7[17:0] (Read/Write)
//         others   - reserved
// 0x0e0 : reserved
// 0x0e4 : Data signal of debl_cfg_theta_8
//         bit 17~0 - debl_cfg_theta_8[17:0] (Read/Write)
//         others   - reserved
// 0x0e8 : reserved
// 0x0ec : Data signal of debl_cfg_theta_9
//         bit 17~0 - debl_cfg_theta_9[17:0] (Read/Write)
//         others   - reserved
// 0x0f0 : reserved
// 0x0f4 : Data signal of debl_cfg_theta_10
//         bit 17~0 - debl_cfg_theta_10[17:0] (Read/Write)
//         others   - reserved
// 0x0f8 : reserved
// 0x0fc : Data signal of debl_cfg_theta_11
//         bit 17~0 - debl_cfg_theta_11[17:0] (Read/Write)
//         others   - reserved
// 0x100 : reserved
// 0x104 : Data signal of debl_cfg_theta_12
//         bit 17~0 - debl_cfg_theta_12[17:0] (Read/Write)
//         others   - reserved
// 0x108 : reserved
// 0x10c : Data signal of debl_cfg_theta_13
//         bit 17~0 - debl_cfg_theta_13[17:0] (Read/Write)
//         others   - reserved
// 0x110 : reserved
// 0x114 : Data signal of debl_cfg_theta_14
//         bit 17~0 - debl_cfg_theta_14[17:0] (Read/Write)
//         others   - reserved
// 0x118 : reserved
// 0x11c : Data signal of debl_cfg_theta_15
//         bit 17~0 - debl_cfg_theta_15[17:0] (Read/Write)
//         others   - reserved
// 0x120 : reserved
// 0x124 : Data signal of debl_cfg_theta_16
//         bit 17~0 - debl_cfg_theta_16[17:0] (Read/Write)
//         others   - reserved
// 0x128 : reserved
// 0x12c : Data signal of debl_cfg_theta_17
//         bit 17~0 - debl_cfg_theta_17[17:0] (Read/Write)
//         others   - reserved
// 0x130 : reserved
// 0x134 : Data signal of debl_cfg_theta_18
//         bit 17~0 - debl_cfg_theta_18[17:0] (Read/Write)
//         others   - reserved
// 0x138 : reserved
// 0x13c : Data signal of debl_cfg_theta_19
//         bit 17~0 - debl_cfg_theta_19[17:0] (Read/Write)
//         others   - reserved
// 0x140 : reserved
// 0x144 : Data signal of debl_cfg_theta_20
//         bit 17~0 - debl_cfg_theta_20[17:0] (Read/Write)
//         others   - reserved
// 0x148 : reserved
// 0x14c : Data signal of debl_cfg_theta_21
//         bit 17~0 - debl_cfg_theta_21[17:0] (Read/Write)
//         others   - reserved
// 0x150 : reserved
// 0x154 : Data signal of debl_cfg_theta_22
//         bit 17~0 - debl_cfg_theta_22[17:0] (Read/Write)
//         others   - reserved
// 0x158 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_B_DDR_DATA                 0x010
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_B_DDR_DATA                 64
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_TAU_DDR_DATA               0x01c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_TAU_DDR_DATA               64
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_LAP_DDR_DATA               0x028
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_LAP_DDR_DATA               64
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_GOER_CFG_COS_OMEGA_0_DATA  0x034
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_GOER_CFG_COS_OMEGA_0_DATA  18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_GOER_CFG_COS_OMEGA_1_DATA  0x03c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_GOER_CFG_COS_OMEGA_1_DATA  18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_GOER_CFG_COS_OMEGA2_0_DATA 0x044
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_GOER_CFG_COS_OMEGA2_0_DATA 18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_GOER_CFG_COS_OMEGA2_1_DATA 0x04c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_GOER_CFG_COS_OMEGA2_1_DATA 18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_GOER_CFG_SIN_OMEGA_0_DATA  0x054
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_GOER_CFG_SIN_OMEGA_0_DATA  18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_GOER_CFG_SIN_OMEGA_1_DATA  0x05c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_GOER_CFG_SIN_OMEGA_1_DATA  18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_N_LAYERS_DATA     0x064
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_N_LAYERS_DATA     8
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_K_DATA            0x06c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_K_DATA            6
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_LAP_OFF_0_DATA    0x074
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_LAP_OFF_0_DATA    12
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_LAP_OFF_1_DATA    0x07c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_LAP_OFF_1_DATA    12
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_LAP_OFF_2_DATA    0x084
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_LAP_OFF_2_DATA    12
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_LAP_OFF_3_DATA    0x08c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_LAP_OFF_3_DATA    12
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_LAP_OFF_4_DATA    0x094
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_LAP_OFF_4_DATA    12
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_LAP_OFF_5_DATA    0x09c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_LAP_OFF_5_DATA    12
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_0_DATA      0x0a4
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_0_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_1_DATA      0x0ac
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_1_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_2_DATA      0x0b4
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_2_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_3_DATA      0x0bc
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_3_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_4_DATA      0x0c4
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_4_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_5_DATA      0x0cc
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_5_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_6_DATA      0x0d4
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_6_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_7_DATA      0x0dc
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_7_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_8_DATA      0x0e4
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_8_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_9_DATA      0x0ec
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_9_DATA      18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_10_DATA     0x0f4
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_10_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_11_DATA     0x0fc
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_11_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_12_DATA     0x104
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_12_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_13_DATA     0x10c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_13_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_14_DATA     0x114
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_14_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_15_DATA     0x11c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_15_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_16_DATA     0x124
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_16_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_17_DATA     0x12c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_17_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_18_DATA     0x134
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_18_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_19_DATA     0x13c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_19_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_20_DATA     0x144
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_20_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_21_DATA     0x14c
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_21_DATA     18
#define XDEEPWAVEACCEL_CTRL_BUS_ADDR_DEBL_CFG_THETA_22_DATA     0x154
#define XDEEPWAVEACCEL_CTRL_BUS_BITS_DEBL_CFG_THETA_22_DATA     18

